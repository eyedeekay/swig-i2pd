#include "textbrowsertweaked1.h"

TextBrowserTweaked1::TextBrowserTweaked1(QWidget * parent): QTextBrowser(parent)
{
}

/*void TextBrowserTweaked1::setSource(const QUrl & url) {
    emit navigatedTo(url);
}*/
