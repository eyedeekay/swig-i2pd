#include "widgetlockregistry.h"

