# Build Requirements

 * Qt 5 is necessary (because Qt4 lacks QtWidgets/ folder)
