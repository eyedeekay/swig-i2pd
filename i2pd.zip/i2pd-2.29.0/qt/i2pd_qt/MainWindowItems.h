#ifndef MAINWINDOWITEMS_H
#define MAINWINDOWITEMS_H

#include <QString>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QCheckBox>

#include <sstream>
#include <functional>

#include "mainwindow.h"

class MainWindow;

#endif // MAINWINDOWITEMS_H
