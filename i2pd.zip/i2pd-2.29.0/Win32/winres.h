#ifndef WINRES_H__
#define WINRES_H__

#include <winresrc.h>

#endif
